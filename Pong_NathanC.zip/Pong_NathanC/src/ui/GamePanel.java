package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GamePanel extends JPanel implements ActionListener, MouseListener, MouseMotionListener, KeyListener {
	private static final long serialVersionUID = 1L;
	
	private int WINDOW_X = 800;
	private int WINDOW_Y = 800;
	
	private int paddleSizeX = 20;
	private int paddleSizeY = 60;
	
	private final int paddlePositionOffset = 50;
	
	private int paddle1Y = (WINDOW_Y / 2) - (paddleSizeY / 2);
	private int paddle2Y = (WINDOW_Y / 2) - (paddleSizeY / 2);
	
	private int paddle1X = paddlePositionOffset;
	private int paddle2X = ((WINDOW_X - paddleSizeX) - paddlePositionOffset);
	
	private int p1Move = 1;
	private int p2Move = -1;
	
	private Timer timer = new Timer(10, this);
	
	public GamePanel(int x, int y) {
		this.addKeyListener(this);
		timer.start();
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		this.setBackground(Color.BLACK);
		g.setColor(Color.WHITE);
		g.fillRect(paddle1X, paddle1Y, paddleSizeX, paddleSizeY);
		g.fillRect(paddle2X, paddle2Y, paddleSizeX, paddleSizeY);
	}

	@Override
	public void mouseDragged(MouseEvent e) {
	}

	@Override
	public void mouseMoved(MouseEvent e) {
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		requestFocus();
		if (p1Move == -1) {
			this.paddle1Y --;
		}
		else if (p1Move == 1) {
			this.paddle1Y ++;
		}
		
		if (p2Move == -1) {
			this.paddle2Y --;
		}
		else if (p2Move == 1) {
			this.paddle2Y ++;
		}
		
		this.repaint();
	}

	@Override
	public void keyPressed(KeyEvent key) {
		if (key.getKeyCode() == 87) {
			p1Move = -1;
		}
		else if (key.getKeyCode() == 83) {
			p1Move = 1;
		}
		else if (key.getKeyCode() == 38) {
			p2Move = -1;
		}
		else if (key.getKeyCode() == 40) {
			p2Move = 1;
		}
	}

	@Override
	public void keyReleased(KeyEvent key) {
	}

	@Override
	public void keyTyped(KeyEvent key) {
	}
}