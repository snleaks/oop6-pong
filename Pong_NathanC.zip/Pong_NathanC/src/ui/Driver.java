package ui;

import javax.swing.*;

public class Driver {
	private final static int WINDOW_X = 800;
	private final static int WINDOW_Y = 800;
	
	public static void main(String[] args) {
		JFrame gameFrame = new JFrame();
		GamePanel gamePanel = new GamePanel(WINDOW_X, WINDOW_Y);
		
		gameFrame.getContentPane().add(gamePanel);
		gameFrame.setSize(WINDOW_X, WINDOW_Y);
		gameFrame.setResizable(false);
		gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gameFrame.setVisible(true);
	}
}
